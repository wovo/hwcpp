RFM70 demo for LPC1114 using the CodeSourcery toolset
use
   make clean run
to build, download and run the application.

This assumes a serial interface to the LPC1114 on COM4
that can reset the chip, force it to bootload mode, and communicate with it.

http://www.voti.nl/rfm70
