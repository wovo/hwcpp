//
// Hi-Tech Lite source file for DB038 board with 16F887:
// HD44780 LED and LED display functions
//
// $Id: db038-leds.c,v 1.1 2011/12/24 13:47:16 Wouter Exp $
//
// (c) Wouter van Ooijen - wouter@voti.nl
//
// Copying and distribution of this file, with or without modification,
// are permitted in any medium without royalty provided the copyright
// notice and this notice are preserved.  This file is offered as-is,
// without any warranty.
// 
// 30-11-2009
//    error in display_decimal_show corrected
//

#include "db038-leds.h"

void display_show(
   unsigned char n,
   unsigned char d,
   unsigned char milliseconds
){
   PIN_DIRECTION( PORTA, 0, INPUT );
   PIN_DIRECTION( PORTA, 1, INPUT );

   PIN_DIRECTION( PORTA, 2, OUTPUT );
   PIN_CLEAR( PORTA, 2 );

   PORT_SET( PORTD, d ^ 0xFF );

   // charge RA1 to high so the speaker will not be affected
   PORT_SET( PORTE, 7 );
   PIN_DIRECTION( PORTA, 1, OUTPUT );
   PIN_SET( PORTA, 1 );
   WAIT_US( 1 );
   PIN_DIRECTION( PORTA, 1, INPUT );

   PORT_SET( PORTE, n );
   TRISE = 0x00;
   TRISD = 0x00;
   PIN_SET( PORTA, 2 );
   wait_ms( milliseconds );
   PIN_CLEAR( PORTA, 2 );
}

void leds_show(
   unsigned char leds,
   unsigned char milliseconds 
){
   display_show( 4, leds, milliseconds );
}

void displays_leds_show(
   unsigned char d0,
   unsigned char d1,
   unsigned char d2,
   unsigned char d3,
   unsigned char leds,
   unsigned char milliseconds
){
   unsigned char i, d;
   PIN_DIRECTION( PORTA, 0, INPUT );
   PIN_DIRECTION( PORTA, 1, INPUT );

   PIN_DIRECTION( PORTA, 2, OUTPUT );
   PIN_CLEAR( PORTA, 2 );

   while( milliseconds > 0 ){
   	  for( i = 0; i < 5; i++ ){
   	  	 switch( i ){
   	  	    case 0: d = d0; break;
   	  	    case 1: d = d1; break;
   	  	    case 2: d = d2; break;
   	  	    case 3: d = d3; break;
   	  	    case 4: d = leds; break;
   	  	 }   	
         PORT_SET( PORTD, d ^ 0xFF );

         // charge RA1 to high so the speaker will not be affected
         PORT_SET( PORTE, 7 );
         PIN_DIRECTION( PORTA, 1, OUTPUT );
         PIN_SET( PORTA, 1 );
         WAIT_US( 1 );
         PIN_DIRECTION( PORTA, 1, INPUT );

         PORT_SET( PORTE, i );
         TRISE = 0x00;
         TRISD = 0x00;
         PIN_SET( PORTA, 2 );
         WAIT_US( 200 );
         PIN_CLEAR( PORTA, 2 );
      }
      milliseconds--;
   }
}

const rom unsigned char seven_segments[ 16 ] = {
   SEVEN_0, 
   SEVEN_1, 
   SEVEN_2, 
   SEVEN_3, 
   SEVEN_4, 
   SEVEN_5, 
   SEVEN_6, 
   SEVEN_7, 
   SEVEN_8, 
   SEVEN_9, 
   SEVEN_A, 
   SEVEN_B, 
   SEVEN_C, 
   SEVEN_D, 
   SEVEN_E, 
   SEVEN_F
};	
	
unsigned char seven_from_nibble( unsigned char x ){
   return seven_segments[ x & 0x0F ];
}

//
// The next two functions use the seven_segments[] array directly, instead
// of calling seven_from_nibble(). The reason is that when the function is 
// called linking and application without calling the function (either
// directly or indirectly) produces a linker error.
//

void display_hexadecimal_show( 
   unsigned int value,
   unsigned char points,
   unsigned char leds,
   unsigned char milliseconds
){
   displays_leds_show(
      seven_segments[( value >> 12 ) & 0x0F ]+( points & 8 ? SEGMENT_DP : 0 ),
      seven_segments[( value >>  8 ) & 0x0F ]+( points & 4 ? SEGMENT_DP : 0 ),
      seven_segments[( value >>  4 ) & 0x0F ]+( points & 2 ? SEGMENT_DP : 0 ),
      seven_segments[( value >>  0 ) & 0x0F ]+( points & 1 ? SEGMENT_DP : 0 ),
      leds,
      milliseconds
   );
}

void display_decimal_show( 
   unsigned int value,
   unsigned char points,
   unsigned char leds,
   unsigned char milliseconds
){
   unsigned char d0, d1, d2, d3;
   d3 = value / 1000;
   value -= d3 * 1000;
   d2 = value / 100;
   value -= d2 * 100;
   d1 = value / 10;
   value -= d1 * 10;
   d0 = value;
   displays_leds_show(
      seven_segments[ d3 & 0x0F ] + ( points & 8 ? SEGMENT_DP : 0 ),
      seven_segments[ d2 & 0x0F ] + ( points & 4 ? SEGMENT_DP : 0 ),
      seven_segments[ d1 & 0x0F ] + ( points & 2 ? SEGMENT_DP : 0 ),
      seven_segments[ d0 & 0x0F ] + ( points & 1 ? SEGMENT_DP : 0 ),
      leds,
      milliseconds
   );
}
