//
// Hi-Tech Lite include file for DB038 board with 16F887:
// HD44780 LED and LED display functions
//
// $Id: db038-leds.h,v 1.1 2011/12/24 13:47:17 Wouter Exp $
//
// (c) Wouter van Ooijen - wouter@voti.nl
//
// Copying and distribution of this file, with or without modification,
// are permitted in any medium without royalty provided the copyright
// notice and this notice are preserved.  This file is offered as-is,
// without any warranty.
// 

#ifndef _DB038_LEDS_H_
#define _DB038_LEDS_H_

#include "db038.h"

#define SEGMENT_A  0b00000001
#define SEGMENT_B  0b00000010
#define SEGMENT_C  0b00000100
#define SEGMENT_D  0b00001000
#define SEGMENT_E  0b00010000
#define SEGMENT_F  0b00100000
#define SEGMENT_G  0b01000000
#define SEGMENT_DP 0b10000000

#define SEVEN_0  0b00111111
#define SEVEN_1  0b00000110
#define SEVEN_2  0b01011011
#define SEVEN_3  0b01001111
#define SEVEN_4  0b01100110
#define SEVEN_5  0b01101101
#define SEVEN_6  0b01111101
#define SEVEN_7  0b00000111
#define SEVEN_8  0b01111111
#define SEVEN_9  0b01101111
#define SEVEN_A  0b01110111
#define SEVEN_B  0b01111100
#define SEVEN_C  0b00111001
#define SEVEN_D  0b01011110
#define SEVEN_E  0b01111001
#define SEVEN_F  0b01110001

void leds_show(
   unsigned char leds,
   unsigned char milliseconds 
);
void display_show(
   unsigned char n,
   unsigned char d,
   unsigned char milliseconds
);   
void displays_leds_show(
   unsigned char d0,
   unsigned char d1,
   unsigned char d2,
   unsigned char d3,
   unsigned char leds,
   unsigned char milliseconds
);
unsigned char seven_from_nibble( unsigned char x );
void display_hexadecimal_show( 
   unsigned int value,
   unsigned char points,
   unsigned char leds,
   unsigned char milliseconds
);
void display_decimal_show( 
   unsigned int value,
   unsigned char points,
   unsigned char leds,
   unsigned char milliseconds
);
   
#endif
