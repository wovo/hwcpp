#
# adapt a source file
#
# author: Wouter van Ooijen (wouter@voti.nl)
# date: 2011-11-21
#

def adapt( variant, inputfiles, outputfile ):
   skip = 0
   substitutions = []
   output = open( outputfile, "w" )
   
   for infile in inputfiles:
      input = open( infile, "r" )
   
      for line in input.xreadlines():
         if line.startswith( "$REPLACE" ):
            x = line.split( None, 3 )
            x.append( "" )
            if ( x[1] == "*" ) or ( x[ 1 ] == variant ):
               substitutions.append( [ x[ 2 ], x[ 3 ].replace( "\n", "" ) ] )
            
         elif line.startswith( "$SPECIFIC" ):
            x = line.split()[ 1 ]
            if x == "END":
               skip = 0
            else:
               skip = ( not variant in x.strip().split(",") )
               
         else:
            if not skip:
               for old, new in substitutions:
                  line = line.replace( old, new )
               output.write( line )
   
      input.close()
   output.close()

if __name__ == '__main__':
   import sys
   if len( sys.argv ) < 4:
      print( "usage: adapt variant inputfile(s) outputfile" )
   else:   
      variant = sys.argv[ 1 ];
      inputfiles = sys.argv[ 2 : len( sys.argv ) - 1 ];
      outputfile = sys.argv[ len( sys.argv ) - 1 ];
      adapt( variant, inputfiles, outputfile )